
package sumadenumeros;

/**
 *
 * @author Cristofer
 */
public class SumaDeNumeros {

    public static void main(String[] args) {
        Recursividad mRecursividad = new Recursividad();
        int resultado = mRecursividad.SumaRecursiva(5);
        System.out.println(resultado);
    }
    
}
